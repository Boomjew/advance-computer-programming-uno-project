package patterns.observer;

import cards.Card;
import players.Player;

/** Concrete Observer: logs every game event to the console. */
public class TurnLogger implements GameObserver {

    @Override
    public void onCardPlayed(Player player, Card card) {
        System.out.println("[LOG] " + player.getName() + " played " + card);
    }

    @Override
    public void onCardDrawn(Player player, int count) {
        System.out.println("[LOG] " + player.getName() + " drew " + count + " card(s).");
    }

    @Override
    public void onTurnChanged(Player nextPlayer) {
        System.out.println("[LOG] --- It is now " + nextPlayer.getName() + "'s turn ---");
    }

    @Override
    public void onUnoCallout(Player caller, Player target) {
        System.out.println("[LOG] " + caller.getName()
            + " called UNO on " + target.getName() + "!");
    }

    @Override
    public void onGameEnd(Player winner) {
        System.out.println("[LOG] *** GAME OVER — Winner: " + winner.getName() + " ***");
    }
}
